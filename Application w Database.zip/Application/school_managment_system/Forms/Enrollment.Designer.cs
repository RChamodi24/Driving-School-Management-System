﻿namespace school_managment_system.Forms
{
    partial class Enrollment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Enrollment));
            this.metroStyleManager1 = new MetroFramework.Components.MetroStyleManager(this.components);
            this.metroTile5 = new MetroFramework.Controls.MetroTile();
            this.metroLink1 = new MetroFramework.Controls.MetroLink();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.sfirstname_box = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.smiddlename_box = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.slastname_box = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.age_box = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.birthcity_box = new MetroFramework.Controls.MetroTextBox();
            this.birthprovince_box = new MetroFramework.Controls.MetroTextBox();
            this.birthregion_box = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.gender_combobox = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.pfirstname_box = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.plastname_box = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.occ_box = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.address_box = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.homephone_box = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.cellphone_box = new MetroFramework.Controls.MetroTextBox();
            this.clr_btn = new MetroFramework.Controls.MetroButton();
            this.metroTile4 = new MetroFramework.Controls.MetroTile();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.id_box = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.class_combobox = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel22 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel23 = new MetroFramework.Controls.MetroLabel();
            this.receip_box = new MetroFramework.Controls.MetroTextBox();
            this.discount_box = new MetroFramework.Controls.MetroTextBox();
            this.done_btn = new MetroFramework.Controls.MetroButton();
            this.tution_lbl = new MetroFramework.Controls.MetroLabel();
            this.other_lbl = new MetroFramework.Controls.MetroLabel();
            this.total_lbl = new MetroFramework.Controls.MetroLabel();
            this.sfirst_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.slast_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.birthdate_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.age_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.gender_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.birthplace_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.pfirst_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.plast_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.occu_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.address_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.homephone_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.id_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.receipt_emptylbl = new MetroFramework.Controls.MetroLabel();
            this.emptytxt_lbl = new MetroFramework.Controls.MetroLabel();
            this.birthdate_box = new MetroFramework.Controls.MetroDateTime();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroStyleManager1
            // 
            this.metroStyleManager1.Owner = this;
            // 
            // metroTile5
            // 
            this.metroTile5.ActiveControl = null;
            this.metroTile5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTile5.Location = new System.Drawing.Point(0, 634);
            this.metroTile5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTile5.Name = "metroTile5";
            this.metroTile5.Size = new System.Drawing.Size(1067, 20);
            this.metroTile5.TabIndex = 61;
            this.metroTile5.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.metroTile5.TileTextFontSize = MetroFramework.MetroTileTextSize.Small;
            this.metroTile5.UseSelectable = true;
            this.metroTile5.UseStyleColors = true;
            // 
            // metroLink1
            // 
            this.metroLink1.BackColor = System.Drawing.Color.Transparent;
            this.metroLink1.BackgroundImage = global::school_managment_system.Properties.Resources.home_icon_grey;
            this.metroLink1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.metroLink1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroLink1.DisplayFocus = true;
            this.metroLink1.ForeColor = System.Drawing.Color.Transparent;
            this.metroLink1.Location = new System.Drawing.Point(3, 12);
            this.metroLink1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroLink1.Name = "metroLink1";
            this.metroLink1.Size = new System.Drawing.Size(68, 42);
            this.metroLink1.TabIndex = 21;
            this.metroLink1.UseCustomForeColor = true;
            this.metroLink1.UseSelectable = true;
            this.metroLink1.Click += new System.EventHandler(this.MetroLink1_Click);
            this.metroLink1.MouseLeave += new System.EventHandler(this.MetroLink1_MouseLeave);
            this.metroLink1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MetroLink1_MouseMove);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.BackColor = System.Drawing.Color.DarkRed;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.metroLabel1.LabelMode = MetroFramework.Controls.MetroLabelMode.Selectable;
            this.metroLabel1.Location = new System.Drawing.Point(79, 22);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(105, 25);
            this.metroLabel1.TabIndex = 53;
            this.metroLabel1.Text = "Enrollment";
            this.metroLabel1.UseCustomForeColor = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(43, 139);
            this.metroLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(74, 17);
            this.metroLabel2.TabIndex = 25;
            this.metroLabel2.Text = "First Name:";
            // 
            // sfirstname_box
            // 
            this.sfirstname_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.sfirstname_box.Lines = new string[0];
            this.sfirstname_box.Location = new System.Drawing.Point(43, 161);
            this.sfirstname_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sfirstname_box.MaxLength = 32767;
            this.sfirstname_box.Name = "sfirstname_box";
            this.sfirstname_box.PasswordChar = '\0';
            this.sfirstname_box.PromptText = "first name";
            this.sfirstname_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.sfirstname_box.SelectedText = "";
            this.sfirstname_box.Size = new System.Drawing.Size(220, 28);
            this.sfirstname_box.TabIndex = 0;
            this.sfirstname_box.UseCustomBackColor = true;
            this.sfirstname_box.UseSelectable = true;
            this.sfirstname_box.WordWrap = false;
            this.sfirstname_box.TextChanged += new System.EventHandler(this.Sfirstname_box_TextChanged);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(272, 139);
            this.metroLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(91, 17);
            this.metroLabel3.TabIndex = 27;
            this.metroLabel3.Text = "Middle Name:";
            // 
            // smiddlename_box
            // 
            this.smiddlename_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.smiddlename_box.Lines = new string[0];
            this.smiddlename_box.Location = new System.Drawing.Point(272, 161);
            this.smiddlename_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.smiddlename_box.MaxLength = 32767;
            this.smiddlename_box.Name = "smiddlename_box";
            this.smiddlename_box.PasswordChar = '\0';
            this.smiddlename_box.PromptText = "middle name";
            this.smiddlename_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.smiddlename_box.SelectedText = "";
            this.smiddlename_box.Size = new System.Drawing.Size(220, 28);
            this.smiddlename_box.TabIndex = 1;
            this.smiddlename_box.UseCustomBackColor = true;
            this.smiddlename_box.UseSelectable = true;
            this.smiddlename_box.WordWrap = false;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(501, 139);
            this.metroLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(73, 17);
            this.metroLabel4.TabIndex = 28;
            this.metroLabel4.Text = "Last Name:";
            // 
            // slastname_box
            // 
            this.slastname_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.slastname_box.Lines = new string[0];
            this.slastname_box.Location = new System.Drawing.Point(501, 161);
            this.slastname_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.slastname_box.MaxLength = 32767;
            this.slastname_box.Name = "slastname_box";
            this.slastname_box.PasswordChar = '\0';
            this.slastname_box.PromptText = "last name";
            this.slastname_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.slastname_box.SelectedText = "";
            this.slastname_box.Size = new System.Drawing.Size(220, 28);
            this.slastname_box.TabIndex = 2;
            this.slastname_box.UseCustomBackColor = true;
            this.slastname_box.UseSelectable = true;
            this.slastname_box.WordWrap = false;
            this.slastname_box.TextChanged += new System.EventHandler(this.Slastname_box_TextChanged);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(31, 96);
            this.metroLabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(109, 17);
            this.metroLabel5.TabIndex = 23;
            this.metroLabel5.Text = "Students Details";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(44, 209);
            this.metroLabel6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(63, 17);
            this.metroLabel6.TabIndex = 30;
            this.metroLabel6.Text = "Birthdate:";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel7.Location = new System.Drawing.Point(317, 212);
            this.metroLabel7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(34, 17);
            this.metroLabel7.TabIndex = 32;
            this.metroLabel7.Text = "Age:";
            // 
            // age_box
            // 
            this.age_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.age_box.Lines = new string[0];
            this.age_box.Location = new System.Drawing.Point(317, 231);
            this.age_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.age_box.MaxLength = 32767;
            this.age_box.Name = "age_box";
            this.age_box.PasswordChar = '\0';
            this.age_box.PromptText = "age";
            this.age_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.age_box.SelectedText = "";
            this.age_box.Size = new System.Drawing.Size(173, 28);
            this.age_box.TabIndex = 4;
            this.age_box.UseCustomBackColor = true;
            this.age_box.UseSelectable = true;
            this.age_box.WordWrap = false;
            this.age_box.TextChanged += new System.EventHandler(this.Age_box_TextChanged);
            this.age_box.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Age_box_KeyPress);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel8.Location = new System.Drawing.Point(43, 292);
            this.metroLabel8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(68, 17);
            this.metroLabel8.TabIndex = 36;
            this.metroLabel8.Text = "Birthplace:";
            // 
            // birthcity_box
            // 
            this.birthcity_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.birthcity_box.Lines = new string[0];
            this.birthcity_box.Location = new System.Drawing.Point(43, 314);
            this.birthcity_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.birthcity_box.MaxLength = 32767;
            this.birthcity_box.Name = "birthcity_box";
            this.birthcity_box.PasswordChar = '\0';
            this.birthcity_box.PromptText = "city";
            this.birthcity_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.birthcity_box.SelectedText = "";
            this.birthcity_box.Size = new System.Drawing.Size(220, 28);
            this.birthcity_box.TabIndex = 6;
            this.birthcity_box.UseCustomBackColor = true;
            this.birthcity_box.UseSelectable = true;
            this.birthcity_box.WordWrap = false;
            this.birthcity_box.TextChanged += new System.EventHandler(this.Birthcity_box_TextChanged);
            // 
            // birthprovince_box
            // 
            this.birthprovince_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.birthprovince_box.Lines = new string[0];
            this.birthprovince_box.Location = new System.Drawing.Point(271, 314);
            this.birthprovince_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.birthprovince_box.MaxLength = 32767;
            this.birthprovince_box.Name = "birthprovince_box";
            this.birthprovince_box.PasswordChar = '\0';
            this.birthprovince_box.PromptText = "province";
            this.birthprovince_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.birthprovince_box.SelectedText = "";
            this.birthprovince_box.Size = new System.Drawing.Size(220, 28);
            this.birthprovince_box.TabIndex = 7;
            this.birthprovince_box.UseCustomBackColor = true;
            this.birthprovince_box.UseSelectable = true;
            this.birthprovince_box.WordWrap = false;
            // 
            // birthregion_box
            // 
            this.birthregion_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.birthregion_box.Lines = new string[0];
            this.birthregion_box.Location = new System.Drawing.Point(500, 314);
            this.birthregion_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.birthregion_box.MaxLength = 32767;
            this.birthregion_box.Name = "birthregion_box";
            this.birthregion_box.PasswordChar = '\0';
            this.birthregion_box.PromptText = "region";
            this.birthregion_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.birthregion_box.SelectedText = "";
            this.birthregion_box.Size = new System.Drawing.Size(220, 28);
            this.birthregion_box.TabIndex = 8;
            this.birthregion_box.UseCustomBackColor = true;
            this.birthregion_box.UseSelectable = true;
            this.birthregion_box.WordWrap = false;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.BackColor = System.Drawing.Color.White;
            this.metroLabel9.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel9.Location = new System.Drawing.Point(501, 209);
            this.metroLabel9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(54, 17);
            this.metroLabel9.TabIndex = 34;
            this.metroLabel9.Text = "Gender:";
            // 
            // gender_combobox
            // 
            this.gender_combobox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.gender_combobox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gender_combobox.FormattingEnabled = true;
            this.gender_combobox.ItemHeight = 24;
            this.gender_combobox.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.gender_combobox.Location = new System.Drawing.Point(501, 231);
            this.gender_combobox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gender_combobox.Name = "gender_combobox";
            this.gender_combobox.PromptText = "gender";
            this.gender_combobox.Size = new System.Drawing.Size(219, 30);
            this.gender_combobox.TabIndex = 5;
            this.gender_combobox.UseCustomBackColor = true;
            this.gender_combobox.UseSelectable = true;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel10.Location = new System.Drawing.Point(31, 380);
            this.metroLabel10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(165, 17);
            this.metroLabel10.TabIndex = 38;
            this.metroLabel10.Text = "Parents/Gardiens Details:";
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel11.Location = new System.Drawing.Point(44, 420);
            this.metroLabel11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(74, 17);
            this.metroLabel11.TabIndex = 39;
            this.metroLabel11.Text = "First Name:";
            // 
            // pfirstname_box
            // 
            this.pfirstname_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pfirstname_box.Lines = new string[0];
            this.pfirstname_box.Location = new System.Drawing.Point(44, 442);
            this.pfirstname_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pfirstname_box.MaxLength = 32767;
            this.pfirstname_box.Name = "pfirstname_box";
            this.pfirstname_box.PasswordChar = '\0';
            this.pfirstname_box.PromptText = "first name";
            this.pfirstname_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.pfirstname_box.SelectedText = "";
            this.pfirstname_box.Size = new System.Drawing.Size(220, 28);
            this.pfirstname_box.TabIndex = 9;
            this.pfirstname_box.UseCustomBackColor = true;
            this.pfirstname_box.UseSelectable = true;
            this.pfirstname_box.WordWrap = false;
            this.pfirstname_box.TextChanged += new System.EventHandler(this.Pfirstname_box_TextChanged);
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel12.Location = new System.Drawing.Point(272, 420);
            this.metroLabel12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(73, 17);
            this.metroLabel12.TabIndex = 41;
            this.metroLabel12.Text = "Last Name:";
            // 
            // plastname_box
            // 
            this.plastname_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.plastname_box.Lines = new string[0];
            this.plastname_box.Location = new System.Drawing.Point(272, 442);
            this.plastname_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.plastname_box.MaxLength = 32767;
            this.plastname_box.Name = "plastname_box";
            this.plastname_box.PasswordChar = '\0';
            this.plastname_box.PromptText = "last name";
            this.plastname_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.plastname_box.SelectedText = "";
            this.plastname_box.Size = new System.Drawing.Size(220, 28);
            this.plastname_box.TabIndex = 10;
            this.plastname_box.UseCustomBackColor = true;
            this.plastname_box.UseSelectable = true;
            this.plastname_box.WordWrap = false;
            this.plastname_box.TextChanged += new System.EventHandler(this.Plastname_box_TextChanged);
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel13.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel13.Location = new System.Drawing.Point(503, 420);
            this.metroLabel13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(77, 17);
            this.metroLabel13.TabIndex = 43;
            this.metroLabel13.Text = "Occupation:";
            // 
            // occ_box
            // 
            this.occ_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.occ_box.Lines = new string[0];
            this.occ_box.Location = new System.Drawing.Point(503, 442);
            this.occ_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.occ_box.MaxLength = 32767;
            this.occ_box.Name = "occ_box";
            this.occ_box.PasswordChar = '\0';
            this.occ_box.PromptText = "occupation";
            this.occ_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.occ_box.SelectedText = "";
            this.occ_box.Size = new System.Drawing.Size(220, 28);
            this.occ_box.TabIndex = 11;
            this.occ_box.UseCustomBackColor = true;
            this.occ_box.UseSelectable = true;
            this.occ_box.WordWrap = false;
            this.occ_box.TextChanged += new System.EventHandler(this.Occ_box_TextChanged);
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel14.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel14.Location = new System.Drawing.Point(43, 495);
            this.metroLabel14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(59, 17);
            this.metroLabel14.TabIndex = 45;
            this.metroLabel14.Text = "Address:";
            // 
            // address_box
            // 
            this.address_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.address_box.Lines = new string[0];
            this.address_box.Location = new System.Drawing.Point(43, 517);
            this.address_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.address_box.MaxLength = 32767;
            this.address_box.Multiline = true;
            this.address_box.Name = "address_box";
            this.address_box.PasswordChar = '\0';
            this.address_box.PromptText = "address";
            this.address_box.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.address_box.SelectedText = "";
            this.address_box.Size = new System.Drawing.Size(317, 60);
            this.address_box.TabIndex = 12;
            this.address_box.UseCustomBackColor = true;
            this.address_box.UseSelectable = true;
            this.address_box.TextChanged += new System.EventHandler(this.Address_box_TextChanged);
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel15.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel15.Location = new System.Drawing.Point(364, 495);
            this.metroLabel15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(86, 17);
            this.metroLabel15.TabIndex = 47;
            this.metroLabel15.Text = "Home Phone:";
            // 
            // homephone_box
            // 
            this.homephone_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.homephone_box.Lines = new string[0];
            this.homephone_box.Location = new System.Drawing.Point(364, 517);
            this.homephone_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.homephone_box.MaxLength = 32767;
            this.homephone_box.Name = "homephone_box";
            this.homephone_box.PasswordChar = '\0';
            this.homephone_box.PromptText = "01234567";
            this.homephone_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.homephone_box.SelectedText = "";
            this.homephone_box.Size = new System.Drawing.Size(175, 28);
            this.homephone_box.TabIndex = 13;
            this.homephone_box.UseCustomBackColor = true;
            this.homephone_box.UseSelectable = true;
            this.homephone_box.WordWrap = false;
            this.homephone_box.TextChanged += new System.EventHandler(this.Homephone_box_TextChanged);
            this.homephone_box.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Homephone_box_KeyPress);
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel16.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel16.Location = new System.Drawing.Point(545, 495);
            this.metroLabel16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(72, 17);
            this.metroLabel16.TabIndex = 49;
            this.metroLabel16.Text = "Cell Phone:";
            // 
            // cellphone_box
            // 
            this.cellphone_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.cellphone_box.Lines = new string[0];
            this.cellphone_box.Location = new System.Drawing.Point(545, 517);
            this.cellphone_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cellphone_box.MaxLength = 32767;
            this.cellphone_box.Name = "cellphone_box";
            this.cellphone_box.PasswordChar = '\0';
            this.cellphone_box.PromptText = "01234567";
            this.cellphone_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.cellphone_box.SelectedText = "";
            this.cellphone_box.Size = new System.Drawing.Size(175, 28);
            this.cellphone_box.TabIndex = 14;
            this.cellphone_box.UseCustomBackColor = true;
            this.cellphone_box.UseSelectable = true;
            this.cellphone_box.WordWrap = false;
            this.cellphone_box.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Cellphone_box_KeyPress);
            // 
            // clr_btn
            // 
            this.clr_btn.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.clr_btn.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.clr_btn.Location = new System.Drawing.Point(31, 599);
            this.clr_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.clr_btn.Name = "clr_btn";
            this.clr_btn.Size = new System.Drawing.Size(100, 28);
            this.clr_btn.TabIndex = 20;
            this.clr_btn.Text = "CLear";
            this.clr_btn.UseSelectable = true;
            this.clr_btn.Click += new System.EventHandler(this.Clr_btn_Click);
            // 
            // metroTile4
            // 
            this.metroTile4.ActiveControl = null;
            this.metroTile4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.metroTile4.Location = new System.Drawing.Point(731, 96);
            this.metroTile4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.metroTile4.Name = "metroTile4";
            this.metroTile4.Size = new System.Drawing.Size(5, 532);
            this.metroTile4.TabIndex = 50;
            this.metroTile4.UseSelectable = true;
            this.metroTile4.UseStyleColors = true;
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel17.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel17.Location = new System.Drawing.Point(745, 139);
            this.metroLabel17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(76, 17);
            this.metroLabel17.TabIndex = 51;
            this.metroLabel17.Text = "Student ID#";
            // 
            // id_box
            // 
            this.id_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.id_box.Lines = new string[0];
            this.id_box.Location = new System.Drawing.Point(843, 134);
            this.id_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.id_box.MaxLength = 32767;
            this.id_box.Name = "id_box";
            this.id_box.PasswordChar = '\0';
            this.id_box.PromptText = "ID";
            this.id_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.id_box.SelectedText = "";
            this.id_box.Size = new System.Drawing.Size(211, 28);
            this.id_box.TabIndex = 15;
            this.id_box.UseCustomBackColor = true;
            this.id_box.UseSelectable = true;
            this.id_box.WordWrap = false;
            this.id_box.TextChanged += new System.EventHandler(this.Id_box_TextChanged);
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel18.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel18.Location = new System.Drawing.Point(745, 209);
            this.metroLabel18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(41, 17);
            this.metroLabel18.TabIndex = 52;
            this.metroLabel18.Text = "Class:";
            // 
            // class_combobox
            // 
            this.class_combobox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.class_combobox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.class_combobox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.class_combobox.FormattingEnabled = true;
            this.class_combobox.ItemHeight = 24;
            this.class_combobox.Items.AddRange(new object[] {
            "Driving Lession 1HR",
            "Class 1",
            "Class 2",
            "Class 3",
            "Class 4",
            "Class 5",
            "Class 6",
            "Class 7",
            "Class 8",
            "Class 9",
            "Driving Lession 2HR"});
            this.class_combobox.Location = new System.Drawing.Point(843, 199);
            this.class_combobox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.class_combobox.Name = "class_combobox";
            this.class_combobox.PromptText = "class";
            this.class_combobox.Size = new System.Drawing.Size(209, 30);
            this.class_combobox.TabIndex = 16;
            this.class_combobox.UseCustomBackColor = true;
            this.class_combobox.UseSelectable = true;
            this.class_combobox.SelectedIndexChanged += new System.EventHandler(this.class_combobox_SelectedIndexChanged);
            this.class_combobox.TextChanged += new System.EventHandler(this.Class_combobox_TextChanged);
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel19.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel19.Location = new System.Drawing.Point(745, 287);
            this.metroLabel19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(77, 17);
            this.metroLabel19.TabIndex = 53;
            this.metroLabel19.Text = "Tution Fees:";
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel20.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel20.Location = new System.Drawing.Point(745, 337);
            this.metroLabel20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(102, 17);
            this.metroLabel20.TabIndex = 54;
            this.metroLabel20.Text = "Others Charges:";
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel21.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel21.Location = new System.Drawing.Point(745, 399);
            this.metroLabel21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(84, 17);
            this.metroLabel21.TabIndex = 55;
            this.metroLabel21.Text = "Discount (%):";
            // 
            // metroLabel22
            // 
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel22.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel22.Location = new System.Drawing.Point(745, 466);
            this.metroLabel22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(88, 17);
            this.metroLabel22.TabIndex = 56;
            this.metroLabel22.Text = "Total Amount:";
            // 
            // metroLabel23
            // 
            this.metroLabel23.AutoSize = true;
            this.metroLabel23.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel23.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel23.Location = new System.Drawing.Point(745, 527);
            this.metroLabel23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel23.Name = "metroLabel23";
            this.metroLabel23.Size = new System.Drawing.Size(106, 17);
            this.metroLabel23.TabIndex = 57;
            this.metroLabel23.Text = "Receipt Number:";
            // 
            // receip_box
            // 
            this.receip_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.receip_box.Lines = new string[0];
            this.receip_box.Location = new System.Drawing.Point(875, 522);
            this.receip_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.receip_box.MaxLength = 32767;
            this.receip_box.Name = "receip_box";
            this.receip_box.PasswordChar = '\0';
            this.receip_box.PromptText = "023232";
            this.receip_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.receip_box.SelectedText = "";
            this.receip_box.Size = new System.Drawing.Size(179, 28);
            this.receip_box.TabIndex = 18;
            this.receip_box.UseCustomBackColor = true;
            this.receip_box.UseSelectable = true;
            this.receip_box.WordWrap = false;
            this.receip_box.TextChanged += new System.EventHandler(this.Receip_box_TextChanged);
            // 
            // discount_box
            // 
            this.discount_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.discount_box.Lines = new string[0];
            this.discount_box.Location = new System.Drawing.Point(857, 394);
            this.discount_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.discount_box.MaxLength = 32767;
            this.discount_box.Name = "discount_box";
            this.discount_box.PasswordChar = '\0';
            this.discount_box.PromptText = "0.0";
            this.discount_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.discount_box.SelectedText = "";
            this.discount_box.Size = new System.Drawing.Size(196, 28);
            this.discount_box.TabIndex = 17;
            this.discount_box.UseCustomBackColor = true;
            this.discount_box.UseSelectable = true;
            this.discount_box.WordWrap = false;
            this.discount_box.TextChanged += new System.EventHandler(this.Discount_box_TextChanged);
            this.discount_box.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Discount_box_KeyPress);
            // 
            // done_btn
            // 
            this.done_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.done_btn.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.done_btn.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.done_btn.Location = new System.Drawing.Point(929, 599);
            this.done_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.done_btn.Name = "done_btn";
            this.done_btn.Size = new System.Drawing.Size(124, 28);
            this.done_btn.TabIndex = 19;
            this.done_btn.Text = "Done";
            this.done_btn.UseSelectable = true;
            this.done_btn.Click += new System.EventHandler(this.Done_btn_Click);
            // 
            // tution_lbl
            // 
            this.tution_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.tution_lbl.AutoSize = true;
            this.tution_lbl.Location = new System.Drawing.Point(897, 287);
            this.tution_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tution_lbl.Name = "tution_lbl";
            this.tution_lbl.Size = new System.Drawing.Size(0, 0);
            this.tution_lbl.TabIndex = 59;
            this.tution_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // other_lbl
            // 
            this.other_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.other_lbl.AutoSize = true;
            this.other_lbl.Location = new System.Drawing.Point(897, 337);
            this.other_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.other_lbl.Name = "other_lbl";
            this.other_lbl.Size = new System.Drawing.Size(0, 0);
            this.other_lbl.TabIndex = 60;
            this.other_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // total_lbl
            // 
            this.total_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.total_lbl.AutoSize = true;
            this.total_lbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.total_lbl.Location = new System.Drawing.Point(877, 466);
            this.total_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.total_lbl.Name = "total_lbl";
            this.total_lbl.Size = new System.Drawing.Size(0, 0);
            this.total_lbl.TabIndex = 62;
            this.total_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sfirst_emptylbl
            // 
            this.sfirst_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.sfirst_emptylbl.AutoSize = true;
            this.sfirst_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.sfirst_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.sfirst_emptylbl.Location = new System.Drawing.Point(243, 134);
            this.sfirst_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sfirst_emptylbl.Name = "sfirst_emptylbl";
            this.sfirst_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.sfirst_emptylbl.TabIndex = 26;
            this.sfirst_emptylbl.Text = "*";
            this.sfirst_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.sfirst_emptylbl.UseCustomForeColor = true;
            this.sfirst_emptylbl.Visible = false;
            // 
            // slast_emptylbl
            // 
            this.slast_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.slast_emptylbl.AutoSize = true;
            this.slast_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.slast_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.slast_emptylbl.Location = new System.Drawing.Point(700, 134);
            this.slast_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.slast_emptylbl.Name = "slast_emptylbl";
            this.slast_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.slast_emptylbl.TabIndex = 29;
            this.slast_emptylbl.Text = "*";
            this.slast_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.slast_emptylbl.UseCustomForeColor = true;
            this.slast_emptylbl.Visible = false;
            // 
            // birthdate_emptylbl
            // 
            this.birthdate_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.birthdate_emptylbl.AutoSize = true;
            this.birthdate_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.birthdate_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.birthdate_emptylbl.Location = new System.Drawing.Point(291, 212);
            this.birthdate_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.birthdate_emptylbl.Name = "birthdate_emptylbl";
            this.birthdate_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.birthdate_emptylbl.TabIndex = 31;
            this.birthdate_emptylbl.Text = "*";
            this.birthdate_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.birthdate_emptylbl.UseCustomForeColor = true;
            this.birthdate_emptylbl.Visible = false;
            // 
            // age_emptylbl
            // 
            this.age_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.age_emptylbl.AutoSize = true;
            this.age_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.age_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.age_emptylbl.Location = new System.Drawing.Point(471, 212);
            this.age_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.age_emptylbl.Name = "age_emptylbl";
            this.age_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.age_emptylbl.TabIndex = 33;
            this.age_emptylbl.Text = "*";
            this.age_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.age_emptylbl.UseCustomForeColor = true;
            this.age_emptylbl.Visible = false;
            // 
            // gender_emptylbl
            // 
            this.gender_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gender_emptylbl.AutoSize = true;
            this.gender_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.gender_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.gender_emptylbl.Location = new System.Drawing.Point(700, 204);
            this.gender_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.gender_emptylbl.Name = "gender_emptylbl";
            this.gender_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.gender_emptylbl.TabIndex = 35;
            this.gender_emptylbl.Text = "*";
            this.gender_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gender_emptylbl.UseCustomForeColor = true;
            this.gender_emptylbl.Visible = false;
            // 
            // birthplace_emptylbl
            // 
            this.birthplace_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.birthplace_emptylbl.AutoSize = true;
            this.birthplace_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.birthplace_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.birthplace_emptylbl.Location = new System.Drawing.Point(244, 287);
            this.birthplace_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.birthplace_emptylbl.Name = "birthplace_emptylbl";
            this.birthplace_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.birthplace_emptylbl.TabIndex = 37;
            this.birthplace_emptylbl.Text = "*";
            this.birthplace_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.birthplace_emptylbl.UseCustomForeColor = true;
            this.birthplace_emptylbl.Visible = false;
            // 
            // pfirst_emptylbl
            // 
            this.pfirst_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pfirst_emptylbl.AutoSize = true;
            this.pfirst_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.pfirst_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.pfirst_emptylbl.Location = new System.Drawing.Point(244, 415);
            this.pfirst_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pfirst_emptylbl.Name = "pfirst_emptylbl";
            this.pfirst_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.pfirst_emptylbl.TabIndex = 40;
            this.pfirst_emptylbl.Text = "*";
            this.pfirst_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pfirst_emptylbl.UseCustomForeColor = true;
            this.pfirst_emptylbl.Visible = false;
            // 
            // plast_emptylbl
            // 
            this.plast_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.plast_emptylbl.AutoSize = true;
            this.plast_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.plast_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.plast_emptylbl.Location = new System.Drawing.Point(471, 415);
            this.plast_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.plast_emptylbl.Name = "plast_emptylbl";
            this.plast_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.plast_emptylbl.TabIndex = 42;
            this.plast_emptylbl.Text = "*";
            this.plast_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.plast_emptylbl.UseCustomForeColor = true;
            this.plast_emptylbl.Visible = false;
            // 
            // occu_emptylbl
            // 
            this.occu_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.occu_emptylbl.AutoSize = true;
            this.occu_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.occu_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.occu_emptylbl.Location = new System.Drawing.Point(700, 415);
            this.occu_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.occu_emptylbl.Name = "occu_emptylbl";
            this.occu_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.occu_emptylbl.TabIndex = 44;
            this.occu_emptylbl.Text = "*";
            this.occu_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.occu_emptylbl.UseCustomForeColor = true;
            this.occu_emptylbl.Visible = false;
            // 
            // address_emptylbl
            // 
            this.address_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.address_emptylbl.AutoSize = true;
            this.address_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.address_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.address_emptylbl.Location = new System.Drawing.Point(336, 490);
            this.address_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.address_emptylbl.Name = "address_emptylbl";
            this.address_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.address_emptylbl.TabIndex = 46;
            this.address_emptylbl.Text = "*";
            this.address_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.address_emptylbl.UseCustomForeColor = true;
            this.address_emptylbl.Visible = false;
            // 
            // homephone_emptylbl
            // 
            this.homephone_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.homephone_emptylbl.AutoSize = true;
            this.homephone_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.homephone_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.homephone_emptylbl.Location = new System.Drawing.Point(519, 490);
            this.homephone_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.homephone_emptylbl.Name = "homephone_emptylbl";
            this.homephone_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.homephone_emptylbl.TabIndex = 48;
            this.homephone_emptylbl.Text = "*";
            this.homephone_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.homephone_emptylbl.UseCustomForeColor = true;
            this.homephone_emptylbl.Visible = false;
            // 
            // id_emptylbl
            // 
            this.id_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.id_emptylbl.AutoSize = true;
            this.id_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.id_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.id_emptylbl.Location = new System.Drawing.Point(1033, 107);
            this.id_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.id_emptylbl.Name = "id_emptylbl";
            this.id_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.id_emptylbl.TabIndex = 58;
            this.id_emptylbl.Text = "*";
            this.id_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.id_emptylbl.UseCustomForeColor = true;
            this.id_emptylbl.Visible = false;
            // 
            // receipt_emptylbl
            // 
            this.receipt_emptylbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.receipt_emptylbl.AutoSize = true;
            this.receipt_emptylbl.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.receipt_emptylbl.ForeColor = System.Drawing.Color.Red;
            this.receipt_emptylbl.Location = new System.Drawing.Point(1033, 495);
            this.receipt_emptylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.receipt_emptylbl.Name = "receipt_emptylbl";
            this.receipt_emptylbl.Size = new System.Drawing.Size(16, 20);
            this.receipt_emptylbl.TabIndex = 61;
            this.receipt_emptylbl.Text = "*";
            this.receipt_emptylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.receipt_emptylbl.UseCustomForeColor = true;
            this.receipt_emptylbl.Visible = false;
            // 
            // emptytxt_lbl
            // 
            this.emptytxt_lbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.emptytxt_lbl.AutoSize = true;
            this.emptytxt_lbl.FontSize = MetroFramework.MetroLabelSize.Small;
            this.emptytxt_lbl.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.emptytxt_lbl.ForeColor = System.Drawing.Color.Red;
            this.emptytxt_lbl.Location = new System.Drawing.Point(380, 59);
            this.emptytxt_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.emptytxt_lbl.Name = "emptytxt_lbl";
            this.emptytxt_lbl.Size = new System.Drawing.Size(184, 17);
            this.emptytxt_lbl.TabIndex = 63;
            this.emptytxt_lbl.Text = "Fields With * Are Mendetory!!!";
            this.emptytxt_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.emptytxt_lbl.UseCustomForeColor = true;
            this.emptytxt_lbl.Visible = false;
            // 
            // birthdate_box
            // 
            this.birthdate_box.CalendarFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.birthdate_box.Location = new System.Drawing.Point(44, 231);
            this.birthdate_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.birthdate_box.MaxDate = new System.DateTime(2020, 12, 31, 0, 0, 0, 0);
            this.birthdate_box.MinDate = new System.DateTime(1995, 1, 1, 0, 0, 0, 0);
            this.birthdate_box.MinimumSize = new System.Drawing.Size(0, 30);
            this.birthdate_box.Name = "birthdate_box";
            this.birthdate_box.Size = new System.Drawing.Size(265, 30);
            this.birthdate_box.TabIndex = 3;
            this.birthdate_box.Value = new System.DateTime(2019, 9, 5, 0, 0, 0, 0);
            // 
            // Enrollment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 654);
            this.ControlBox = false;
            this.Controls.Add(this.birthdate_box);
            this.Controls.Add(this.total_lbl);
            this.Controls.Add(this.other_lbl);
            this.Controls.Add(this.tution_lbl);
            this.Controls.Add(this.metroTile4);
            this.Controls.Add(this.done_btn);
            this.Controls.Add(this.clr_btn);
            this.Controls.Add(this.class_combobox);
            this.Controls.Add(this.gender_combobox);
            this.Controls.Add(this.age_box);
            this.Controls.Add(this.birthregion_box);
            this.Controls.Add(this.birthprovince_box);
            this.Controls.Add(this.birthcity_box);
            this.Controls.Add(this.occ_box);
            this.Controls.Add(this.plastname_box);
            this.Controls.Add(this.slastname_box);
            this.Controls.Add(this.smiddlename_box);
            this.Controls.Add(this.cellphone_box);
            this.Controls.Add(this.homephone_box);
            this.Controls.Add(this.address_box);
            this.Controls.Add(this.pfirstname_box);
            this.Controls.Add(this.receip_box);
            this.Controls.Add(this.discount_box);
            this.Controls.Add(this.id_box);
            this.Controls.Add(this.sfirstname_box);
            this.Controls.Add(this.metroLabel18);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel10);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel13);
            this.Controls.Add(this.metroLabel12);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel16);
            this.Controls.Add(this.metroLabel15);
            this.Controls.Add(this.metroLabel23);
            this.Controls.Add(this.metroLabel14);
            this.Controls.Add(this.metroLabel22);
            this.Controls.Add(this.metroLabel21);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.metroLabel20);
            this.Controls.Add(this.metroLabel19);
            this.Controls.Add(this.metroLabel17);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroLink1);
            this.Controls.Add(this.metroTile5);
            this.Controls.Add(this.receipt_emptylbl);
            this.Controls.Add(this.id_emptylbl);
            this.Controls.Add(this.homephone_emptylbl);
            this.Controls.Add(this.address_emptylbl);
            this.Controls.Add(this.occu_emptylbl);
            this.Controls.Add(this.plast_emptylbl);
            this.Controls.Add(this.pfirst_emptylbl);
            this.Controls.Add(this.birthplace_emptylbl);
            this.Controls.Add(this.gender_emptylbl);
            this.Controls.Add(this.age_emptylbl);
            this.Controls.Add(this.birthdate_emptylbl);
            this.Controls.Add(this.slast_emptylbl);
            this.Controls.Add(this.emptytxt_lbl);
            this.Controls.Add(this.sfirst_emptylbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Enrollment";
            this.Padding = new System.Windows.Forms.Padding(27, 74, 27, 25);
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Load += new System.EventHandler(this.Enrollment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Components.MetroStyleManager metroStyleManager1;
        private MetroFramework.Controls.MetroTile metroTile5;
        private MetroFramework.Controls.MetroLink metroLink1;
        private MetroFramework.Controls.MetroComboBox gender_combobox;
        private MetroFramework.Controls.MetroTextBox age_box;
        private MetroFramework.Controls.MetroTextBox birthregion_box;
        private MetroFramework.Controls.MetroTextBox birthprovince_box;
        private MetroFramework.Controls.MetroTextBox birthcity_box;
        private MetroFramework.Controls.MetroTextBox occ_box;
        private MetroFramework.Controls.MetroTextBox plastname_box;
        private MetroFramework.Controls.MetroTextBox slastname_box;
        private MetroFramework.Controls.MetroTextBox smiddlename_box;
        private MetroFramework.Controls.MetroTextBox cellphone_box;
        private MetroFramework.Controls.MetroTextBox homephone_box;
        private MetroFramework.Controls.MetroTextBox address_box;
        private MetroFramework.Controls.MetroTextBox pfirstname_box;
        private MetroFramework.Controls.MetroTextBox sfirstname_box;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroButton clr_btn;
        private MetroFramework.Controls.MetroTile metroTile4;
        private MetroFramework.Controls.MetroComboBox class_combobox;
        private MetroFramework.Controls.MetroTextBox receip_box;
        private MetroFramework.Controls.MetroTextBox discount_box;
        private MetroFramework.Controls.MetroTextBox id_box;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private MetroFramework.Controls.MetroLabel metroLabel23;
        private MetroFramework.Controls.MetroLabel metroLabel22;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel total_lbl;
        private MetroFramework.Controls.MetroLabel other_lbl;
        private MetroFramework.Controls.MetroLabel tution_lbl;
        private MetroFramework.Controls.MetroButton done_btn;
        private MetroFramework.Controls.MetroLabel receipt_emptylbl;
        private MetroFramework.Controls.MetroLabel id_emptylbl;
        private MetroFramework.Controls.MetroLabel homephone_emptylbl;
        private MetroFramework.Controls.MetroLabel address_emptylbl;
        private MetroFramework.Controls.MetroLabel occu_emptylbl;
        private MetroFramework.Controls.MetroLabel plast_emptylbl;
        private MetroFramework.Controls.MetroLabel pfirst_emptylbl;
        private MetroFramework.Controls.MetroLabel birthplace_emptylbl;
        private MetroFramework.Controls.MetroLabel gender_emptylbl;
        private MetroFramework.Controls.MetroLabel age_emptylbl;
        private MetroFramework.Controls.MetroLabel birthdate_emptylbl;
        private MetroFramework.Controls.MetroLabel slast_emptylbl;
        private MetroFramework.Controls.MetroLabel sfirst_emptylbl;
        private MetroFramework.Controls.MetroLabel emptytxt_lbl;
        private MetroFramework.Controls.MetroDateTime birthdate_box;
    }
}